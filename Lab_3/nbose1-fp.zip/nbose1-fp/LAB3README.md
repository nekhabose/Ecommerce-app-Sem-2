NEKHA BOSE Lab 3 README

POJO implementation and HTML form

<img width="629" alt="Screen Shot" src="https://github.com/user-attachments/assets/a847243e-edb0-466f-a310-495f9e6aec47">

Servlet MVC Controller

The form for entering the customer details is given below:

<img width="738" alt="Screen Shot 2" src="https://github.com/user-attachments/assets/319cdd19-6db9-49ee-b900-b78af7096251">

The confirmation page after the customer details are entered are given below:

<img width="542" alt="Screen Shot 3" src="https://github.com/user-attachments/assets/b97833c7-afad-43cf-848d-27d6e839c30c">

Servlet MVC Controller RequestDispatcher logic


Form with invalid input
![img1](https://github.com/user-attachments/assets/0f1b9d2b-a4f7-4ef0-9f77-bd0e2aaeec63)

Form with error inputs

![img2](https://github.com/user-attachments/assets/25024718-ee7f-48c4-9203-def64e91c284)

The error fields has been filled up.
![img3](https://github.com/user-attachments/assets/823ae4a3-6c45-4939-9003-8d845718ba99) 

Confirmation page.
![img4](https://github.com/user-attachments/assets/862f4748-c8b5-4e42-9dfc-5d0c8153bd77)



